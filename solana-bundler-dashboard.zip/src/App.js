
import React, { useState } from 'react';
import './App.css';

const BACKEND_URL = 'https://bba9fbd0-915a-49a6-b23d-b890353b5da9-00-31rdipvky5xco.spock.replit.dev';

const App = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [log, setLog] = useState('');

  const login = () => {
    if (username === 'zezzi' && password === 'monkeymonkey') {
      setLoggedIn(true);
    } else {
      alert('Wrong username or password');
    }
  };

  const sendCommand = async (endpoint) => {
    try {
      const response = await fetch(`${BACKEND_URL}${endpoint}`, { method: 'GET' });
      const data = await response.text();
      setLog(data);
    } catch (error) {
      setLog('Error: ' + error.message);
    }
  };

  if (!loggedIn) {
    return (
      <div className="login">
        <h2>Login</h2>
        <input placeholder="Username" onChange={e => setUsername(e.target.value)} />
        <input placeholder="Password" type="password" onChange={e => setPassword(e.target.value)} />
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return (
    <div className="admin">
      <h1>Solana Bundler Dashboard</h1>
      <button onClick={() => sendCommand('/run/create-wallets')}>Create Wallets</button>
      <button onClick={() => sendCommand('/run/premarket')}>Premarket</button>
      <button onClick={() => sendCommand('/run/create-pool')}>Create Pool</button>
      <button onClick={() => sendCommand('/run/sell-all')}>Sell All</button>
      <button onClick={() => sendCommand('/run/remove-lp')}>Remove LP</button>
      <pre>{log}</pre>
    </div>
  );
};

export default App;
